# Velge rett lisens til eget arbeid.
Det er lurt å bruke litt tid på dette og gjøre deg kjent på området.

Når en legger ut arbeid alle kan se er det greit å definere en lisens innholdet føgler.
På denne måten kan en som forfatter styre bruken
Lisensen som er valgt er en MIT-lisens men den "snille" versjone som ikke legger ved restriksjoner.
Om du vil gjøre deg kjent med dette selv så har du denne lenken under

https://choosealicense.com/appendix/

Kose deg med reisen inn på OSS programvare Søk på nett etter OSS eller Open Source OSS, så slipper du så mange falke
resultat.OSI er et annet ord med det har litt mange betydinger så ta med mange ord når du søker, free, open source, oss, osi ...
