# cliogkoding
Denne er opprinnelig til en oppgave som skal leveres inn.  
Den vil ogsaa tjene som et lagersted for ulike script og koding.  
This is so far in Norwegian, but may later be written in English.
## Se seksjonen innlevering uder
## The whole ifdea behind this repository it to publish, own work and potentially even others work.
The plan is to include inside the source code the potentially used sources.
If anyone sees their own work with not a proper credit, let me know so I can fix it.

It is an experiment to produce almost everythin to this task, on github.
The repository name is a wordplay on my name and the school I am currently associated with.

The plan is to start using revisison histroy and source revision tool to a higher ecxtent, than earlier,
and to familiarise my self more with git. Another plan is to inform and introduce new students and pupils to this tool.

There are many politiacl obsticals for students to use this type of SW, regardin GDPR etc.
There er several issues for students under 18 yerars ogf age to use such tools as github, so this has to be remebered and 
taken into cosideration

# So what is this repository about. Whel the general idea is to use CLI-tool in different OS and envitonments.

For now, python, bash, batch/cmd, powershell might be included.
There is nothing new on the page if you are looking for a script to do a job. It is merely my own playground.

## The focus is about using cli-tools in both scripts and on command line to achieve some goals.
Feel fre to explore the ddifferent folders tos find scripts., and this page for any futre updates.


# Innlevering
Det leveres digitalt en zip-fil i rett program for innlevering.
Denne zip-fil er en versjon av denne siden / dette innholdet på en gitt dato, og edenne siden lever videre, både med tanke på korrigere skrivefeil eller strukturendringer.
På den mpten får en litt i pose og sekk.
Innlevering innholder også en lenke til andre steder, f.eks. der en hjemmeside ligger eller der ulike vedlge eller mengder anndre resurser.
Disse finnes også i denne plasseringen på github under:

https://github.com/kvapehe/cliogkoding/

Og strengt tatt  skal det være nok å ha denne for å få tak i alt innholdet.
Mappen for innlevering er her:
https://github.com/kvapehe/cliogkoding/blob/main/innlevering/innlevering001.md

2023-05-05
